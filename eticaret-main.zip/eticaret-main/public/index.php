<?php
declare(strict_types=1);

use App\Core\Router;
use App\Core\Route;

session_start();

error_reporting(E_ALL);
ini_set('display_errors', '1');

$root = dirname(__DIR__);

// Composer autoload (for Dotenv, etc.)
if (file_exists($root . '/vendor/autoload.php')) {
	require_once $root . '/vendor/autoload.php';
	// Load .env if present; support multiple Dotenv major versions or skip on failure
	if (file_exists($root . '/.env') && class_exists('Dotenv\\Dotenv')) {
		try {
			if (class_exists('Dotenv\\Repository\\RepositoryBuilder') && method_exists('Dotenv\\Dotenv', 'createImmutable')) {
				$dotenv = Dotenv\Dotenv::createImmutable($root);
				$dotenv->load();
			} else {
				$dotenv = new Dotenv\Dotenv($root);
				$dotenv->load();
			}
		} catch (\Throwable $e) {
			// Fallback defaults below will be used
		}
	}
}

// Fallback defaults for local dev if .env not loaded
$_ENV['DB_HOST'] = $_ENV['DB_HOST'] ?? '127.0.0.1';
$_ENV['DB_NAME'] = $_ENV['DB_NAME'] ?? 'sepet_db';
$_ENV['DB_USER'] = $_ENV['DB_USER'] ?? 'root';
$_ENV['DB_PASS'] = $_ENV['DB_PASS'] ?? '';

// Manually include core and model classes (no PSR-4 autoload configured)
require_once $root . '/app/core/router.php';
require_once $root . '/app/core/Route.php';
require_once $root . '/app/core/Database.php';
require_once $root . '/app/core/View.php';
require_once $root . '/app/core/Auth.php';
require_once $root . '/app/Help/validation.php';
require_once $root . '/app/Help/Upload.php';
require_once $root . '/app/models/UserModel.php';
require_once $root . '/app/models/ProductModel.php';

// Load custom routes
if (file_exists($root . '/app/config/routes.php')) {
	require_once $root . '/app/config/routes.php';
}

// Try route table first (supports '/', named params etc.)
$requestUri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$basePath = $scriptDir === '' || $scriptDir === '/' ? '' : $scriptDir;
$path = '/' . ltrim(preg_replace('#^' . preg_quote($basePath, '#') . '#', '', $requestUri), '/');

if (!Route::dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $path)) {
	// Fallback to legacy router (?url=controller/method/param)
	Router::dispatch();
}


