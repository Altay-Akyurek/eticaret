<?php
// Root bootstrap: forward to public front controller
require __DIR__ . '/public/index.php';


