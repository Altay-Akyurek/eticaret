<?php
namespace App\Controllers;

use App\Core\View;
use App\Models\ProductModel;
use App\Models\UserModel;

class AdminController
{
    private function checkAuth()
    {
        if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
            header("Location: /admin/login");
            exit;
        }
    }

    public function dashboard() 
    {
        $this->checkAuth();

        $productModel = new ProductModel();
        $userModel    = new UserModel();

        $products = $productModel->getAll();
        $users    = $userModel->getAll();

        View::render("admin/dashboard", [
            "products" => $products,
            "users"    => $users
        ]);
    }

    public function products()
    {
        $this->checkAuth();

        $productModel = new ProductModel();
        $products     = $productModel->getAll();

        View::render("admin/product", [
            "products" => $products
        ]);  
    }
}
