<?php
use App\Core\Route;

// Root = home
Route::get('/home', 'HomeController@index');

// Auth
Route::get('/auth/login', 'AuthController@login');
Route::post('/auth/login', 'AuthController@login');
Route::get('/auth/logout', 'AuthController@logout');

// Register
Route::get('/register/store', 'RegisterController@store');
Route::post('/register/store', 'RegisterController@store');

// Products
Route::get('/product/index', 'ProductController@index');
Route::get('/product/detail/{id}', 'ProductController@detail');


