<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Ürün Detayı</title>
</head>
<body>
    <?php if (!empty($product)): ?>
        <h2><?= htmlspecialchars($product['name']) ?></h2>
        <p>Fiyat: <?= htmlspecialchars($product['price']) ?> TL</p>
        <p><a href="/eticaret-main/public/product/index">Geri</a></p>
    <?php else: ?>
        <p>Ürün bulunamadı.</p>
    <?php endif; ?>
</body>
</html>

