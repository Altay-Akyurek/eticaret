<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($title) ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }
        .products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }
        .product {
            background: white;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .product:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
        }
        .product h3 {
            margin: 10px 0;
            color: #444;
        }
        .product p {
            font-size: 18px;
            font-weight: bold;
            color: #27ae60;
            margin: 5px 0 15px;
        }
        .add-to-cart {
            background: #27ae60;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.2s;
        }
        .add-to-cart:hover {
            background: #219150;
        }
        .added {
            background: #f39c12 !important;
        }
    </style>
</head>
<body>

<h1><?= htmlspecialchars($title) ?></h1>

<div class="products">
    <?php foreach ($products as $p): ?>
        <div class="product">
            <h3><?= htmlspecialchars($p['name']) ?></h3>
            <p><?= number_format($p['price'], 2) ?> ₺</p>
            <button class="add-to-cart">Sepete Ekle</button>
        </div>
    <?php endforeach; ?>
</div>

<script>
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', function() {
            this.textContent = "Eklendi ✓";
            this.classList.add("added");
            setTimeout(() => {
                this.textContent = "Sepete Ekle";
                this.classList.remove("added");
            }, 1500);
        });
    });
</script>

</body>
</html>
