<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kayıt Başarılı</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <h2>Kayıt Başarılı!</h2>
    <p>Hoş geldin, <?= htmlspecialchars($username ?? '') ?>!</p>
    <p>E-posta: <?= htmlspecialchars($email ?? '') ?></p>

    <?php if (!empty($avatar)): ?>
        <p>Profil Fotoğrafın:</p>
        <img src="/php/php_calısmaları/eticaret-main/assets/upload/<?= htmlspecialchars($avatar) ?>" 
             alt="Avatar" style="max-width:200px;">
    <?php endif; ?>

    <br><br>
    <a href="/php/php_calısmaları/eticaret-main/auth/login">Giriş Yap</a>
</body>
</html>
